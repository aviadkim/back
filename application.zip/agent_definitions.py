agents = [
    "Deployment", "Performance", "Security", "UI/UX", "Database",
    "Frontend", "Backend", "Testing", "Documentation", "Client Experience",
    "Refactoring", "Dependency", "Error Handling", "Scalability", "Containerization",
    "API", "Code Style", "Build", "Internationalization", "Accessibility"
]
