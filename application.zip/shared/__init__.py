# Initialize shared module
