def get_classifier():
    """Placeholder for document classifier."""
    return lambda x: {"document_type": "unknown"}