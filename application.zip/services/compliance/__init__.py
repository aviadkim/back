def get_compliance_service():
    """Placeholder for compliance service."""
    return lambda x: {"compliance_status": "unknown"}