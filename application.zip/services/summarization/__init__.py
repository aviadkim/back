def get_summarizer():
    """Placeholder for summarizer."""
    return lambda x: {"summary": "Placeholder summary"}