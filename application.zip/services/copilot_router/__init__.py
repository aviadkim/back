def get_router_service():
    """Placeholder for router service."""
    return lambda x: {"route": "default"}